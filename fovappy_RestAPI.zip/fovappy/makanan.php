<?php
require'koneksi.php';

$cek = mysqli_affected_rows($konek);

if(isset($_GET["key"])){
    
    $key = $_GET["key"];
    $per = "SELECT * FROM tbl_makanan where id_restaurant = '3'";
    $eks = mysqli_query($konek, $per);
    $response["makanan"] = array();
    

    while($take = mysqli_fetch_object($eks)){
        $G["id_makanan"] = $take->id_makanan;
        $G["nama_makanan"] = $take->nama_makanan;
        $G["harga"] = $take->harga;
        $G["deskripsi"] = $take->deskripsi;
        $G["id_restaurant"] = $take->id_restaurant;

        array_push($response["makanan"], $G);
    }
} else {
    $per = "SELECT * FROM tbl_makanan";
    $eks = mysqli_query($konek, $per);
    $response["data"] = array();
    $response["makanan"] = array();
    

    while($take = mysqli_fetch_object($eks)){
        $G["id_makanan"] = $take->id_makanan;
        $G["nama_makanan"] = $take->nama_makanan;
        $G["harga"] = $take->harga;
        $G["deskripsi"] = $take->deskripsi;
        $G["id_restaurant"] = $take->id_restaurant;

        array_push($response["makanan"], $G);
    }
}

echo json_encode($response);
mysqli_close($konek);

