<?php
require'koneksi.php';
$perintah = "SELECT * FROM tbl_restaurant";
$eksekusi = mysqli_query($konek, $perintah);
$per = "SELECT * FROM tbl_makanan";

$eks = mysqli_query($konek, $per);
$cek = mysqli_affected_rows($konek);

if($cek > 0){
    $response["kode"] = 1;
    $response["pesan"] = "Data Tersedia";
    $response["data"] = array();

    while($ambil = mysqli_fetch_object($eksekusi)){
        $F["id"] = $ambil->id;
        $F["nama_restaurant"] = $ambil->nama_restaurant;
        $F["rating"] = $ambil->rating;
        $F["waktu"] = $ambil->waktu;
        $F["alamat"] = $ambil->alamat;
        $F["asal"] = $ambil->asal;

        array_push($response["data"], $F);
    }
    $response["makanan"] = array();

    while($take = mysqli_fetch_object($eks)){
        $G["id_makanan"] = $take->id_makanan;
        $G["nama_makanan"] = $take->nama_makanan;
        $G["harga"] = $take->harga;
        $G["deskripsi"] = $take->deskripsi;
        $G["id_restaurant"] = $take->id_restaurant;

        array_push($response["makanan"], $G);
    }
} else {
    $response["kode"] = 0;
    $response["pesan"] = "Data Tidak Tersedia";
}

echo json_encode($response);
mysqli_close($konek);
