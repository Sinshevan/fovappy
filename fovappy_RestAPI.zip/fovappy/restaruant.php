<?php
require'koneksi.php';

$cek = mysqli_affected_rows($konek);

if(isset($_GET["key"])){
    
    $key = $_GET["key"];
    $perintah = "SELECT * FROM tbl_restaurant where id = '3'";
    $eksekusi = mysqli_query($konek, $perintah);
    $response["data"] = array();
    

    while($ambil = mysqli_fetch_object($eksekusi)){
        $F["id"] = $ambil->id;
        $F["nama_restaurant"] = $ambil->nama_restaurant;
        $F["rating"] = $ambil->rating;
        $F["waktu"] = $ambil->waktu;
        $F["alamat"] = $ambil->alamat;
        $F["asal"] = $ambil->asal;

        array_push($response["data"], $F);
        
    }

} else {
    $perintah = "SELECT * FROM tbl_restaurant";
    $eksekusi = mysqli_query($konek, $perintah);
    $response["data"] = array();
    

    while($ambil = mysqli_fetch_object($eksekusi)){
        $F["id"] = $ambil->id;
        $F["nama_restaurant"] = $ambil->nama_restaurant;
        $F["rating"] = $ambil->rating;
        $F["waktu"] = $ambil->waktu;
        $F["alamat"] = $ambil->alamat;
        $F["asal"] = $ambil->asal;

        array_push($response["data"], $F);
        
    }

}

echo json_encode($response);
mysqli_close($konek);

