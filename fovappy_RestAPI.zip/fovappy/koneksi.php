<?php
$host = "localhost";
$user = "id20064462_fovappy";
$pass = "Drag0n!23A56";
$db = "id20064462_db_fovappy";

$konek = mysqli_connect($host, $user, $pass, $db) or die("Database MYSQL Tidak Terhubung");;
